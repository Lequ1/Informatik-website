tailwind.config = {
    theme: {
        extend: {
            colors: {
                'black': "#050505" // or #1C1D21
            },
        }
    }
}